vim.cmd('syntax on')

vim.opt.tabstop = 4
vim.opt.shiftwidth = 4
vim.opt.smartindent = true
vim.opt.number = true

vim.api.nvim_set_keymap('n', 'H', '<C-d>', { noremap = true })
vim.api.nvim_set_keymap('n', 'L', '<C-u>', { noremap = true })
vim.api.nvim_set_keymap('n', 'J', '5<C-e>5j', { noremap = true })
vim.api.nvim_set_keymap('n', 'K', '5<C-y>5k', { noremap = true })
vim.api.nvim_set_keymap('n', 'M', 'M7k0', { noremap = true })
vim.api.nvim_set_keymap('n', 'zt', 'zt5<C-y>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-@>', '<C-w><C-w>', { noremap = true })
vim.api.nvim_set_keymap('t', '<Esc>', [[<C-\><C-n>]], { noremap = true })
vim.api.nvim_set_keymap('n', '<C-k><C-n>', ':tabnew<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-k><C-c>', ':tabclose<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-k><C-j>', ':tabnext -1<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-k><C-l>', ':tabnext +1<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-j><C-j>', ':term<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-j><C-k>', ':top term<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-j><C-l>', ':vert term<CR>', { noremap = true })
vim.api.nvim_set_keymap('t', '<C-q>', '<Esc>', { noremap = true, silent = true})

vim.opt.backspace = { 'indent', 'eol', 'start' }
vim.opt.laststatus = 2
vim.api.nvim_create_autocmd('FileType', {
	pattern = { 'c', 'h' },
	callback = function()
		vim.opt_local.shiftwidth = 8
		vim.opt_local.softtabstop = 8
		vim.opt_local.tabstop = 8
		vim.opt_local.expandtab = true
	end,
})

vim.api.nvim_set_keymap('n', '<C-h>', ':Gtags -f %<CR>', { noremap = true })
vim.api.nvim_set_keymap('n', '<C-j>', ':GtagsCursor<CR>', { noremap = true })

vim.api.nvim_create_user_command("C", function(opts)
  local t
  if opts.range > 0 then
    t = table.concat(vim.api.nvim_buf_get_lines(0, opts.line1-1, opts.line2, false), "\n")
  else
    local s,e = vim.api.nvim_buf_get_mark(0,"<"), vim.api.nvim_buf_get_mark(0,">")
    if s[1]==0 then return end
    t = table.concat(vim.api.nvim_buf_get_text(0, s[1]-1, s[2], e[1]-1, e[2]+1, {}), "\n")
  end
  if vim.fn.executable("wl-copy")==1 then
    if vim.system then vim.system({"wl-copy"},{stdin=t})
    else local j=vim.fn.jobstart({"wl-copy"},{stdin="pipe"}); vim.fn.chansend(j,t); vim.fn.chanclose(j,"stdin") end
  else
    vim.fn.setreg("+", t)
  end
end, { range = true, desc = "Copy visual/range to wl-copy (fallback: +)" })

vim.api.nvim_create_user_command("P", function()
  local t
  if vim.fn.executable("wl-paste") == 1 then
    t = vim.fn.system({ "wl-paste", "--no-newline" })
    if vim.v.shell_error ~= 0 or t == "" then t = nil end
  end
  if not t or t == "" then
    t = vim.fn.getreg("+")
    if t == "" then return end
  end
  vim.api.nvim_paste(t, true, -1)  -- カーソル位置に貼る（改行も可）
end, { desc = "Paste wl-paste (fallback: + register) if non-empty" })

local dracula = require("dracula")
dracula.setup({
  -- customize dracula color palette
  colors = {
    bg = "#282A36",
    fg = "#F8F8F2",
    selection = "#44475A",
    comment = "#FFB86C",
    red = "#FF5555",
    orange = "#FFB86C",
    yellow = "#F1FA8C",
    green = "#50fa7b",
    purple = "#BD93F9",
    cyan = "#8BE9FD",
    pink = "#FF79C6",
    bright_red = "#FF6E6E",
    bright_green = "#69FF94",
    bright_yellow = "#FFFFA5",
    bright_blue = "#D6ACFF",
    bright_magenta = "#FF92DF",
    bright_cyan = "#A4FFFF",
    bright_white = "#FFFFFF",
    menu = "#21222C",
    visual = "#3E4452",
    gutter_fg = "#4B5263",
    nontext = "#3B4048",
    white = "#ABB2BF",
    black = "#191A21",
  },
  -- show the '~' characters after the end of buffers
  show_end_of_buffer = true, -- default false
  -- use transparent background
  transparent_bg = true, -- default false
  -- set custom lualine background color
  lualine_bg_color = "#44475a", -- default nil
  -- set italic comment
  italic_comment = true, -- default false
  -- overrides the default fhighlights with table see `:h synIDattr`
  overrides = {},
  -- You can use overrides as table like this
  -- overrides = {
  --   NonText = { fg = "white" }, -- set NonText fg to white
  --   NvimTreeIndentMarker = { link = "NonText" }, -- link to NonText highlight
  --   Nothing = {} -- clear highlight of Nothing
  -- },
  -- Or you can also use it like a function to get color from theme
  -- overrides = function (colors)
  --   return {
  --     NonText = { fg = colors.white }, -- set NonText fg to white of theme
  --   }
  -- end,
})

vim.cmd[[colorscheme dracula]]
vim.api.nvim_set_hl(0, "Comment", { fg = "#f8b659" })

vim.api.nvim_create_user_command('Novel', function()
	vim.g.better_whitespace_enabled = 0
	vim.cmd('Tate')
end, {})
